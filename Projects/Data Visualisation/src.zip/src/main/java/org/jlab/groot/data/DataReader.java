/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.jlab.groot.data;

/**
 *
 * @author gavalian
 */
public class DataReader {
    
    public static H1F h1f(String filename){
        H1F h1 = new H1F();
        return h1;
    }
}
